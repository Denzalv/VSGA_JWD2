<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Proses</title>
</head>
<body>
		<?php 
			//bilangan pertama
			$arg_pertama = $_POST['nilsatu'];
			//bilangan kedua
			$arg_kedua = $_POST['nildua'];
			// new line
			$newline = "<br>";
			//garis horizontal
			$line = "<hr style='margin: 2px;'>";

			//penjumlahan
			function penjumlahan($param_pertama, $param_kedua) {
				echo "hasil penjumlahan adalah : " . $param_pertama + $param_kedua;
			}
			//pengurangan
			function pengurangan($param_pertama, $param_kedua) {
				echo "hasil pengurangan adalah : " . $param_pertama - $param_kedua;
			}
			//perkalian
			function perkalian($param_pertama, $param_kedua) {
				echo "hasil perkalian adalah : " . $param_pertama * $param_kedua;
			}
			//pembagian
			function pembagian($param_pertama, $param_kedua) {
				echo "hasil pembagian adalah : " . $param_pertama / $param_kedua;
			}

		//menampilkan bilangan yang di operasikan
		// echo "Bilangan $arg_pertama & $arg_kedua";
		// garis pertama
		// echo $line;
		// garis kedua
		// echo $line;

		?>

		
		<?php
		//memasukan nilai argumen pada pemanggilan fungsi
		penjumlahan($arg_pertama,$arg_kedua);
		// new line
		echo $newline;
		//memasukan nilai argumen pada pemanggilan fungsi
		pengurangan($arg_pertama,$arg_kedua);
		echo $newline;		
		//memasukan nilai argumen pada pemanggilan fungsi
		perkalian($arg_pertama,$arg_kedua);
		// new line
		echo $newline;		
		//memasukan nilai argumen pada pemanggilan fungsi
		pembagian($arg_pertama,$arg_kedua);

	?>
</body>
</html>
